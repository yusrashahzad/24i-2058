# FAST Data Analysis & Visualization - Lab 12
# Complete reproducible analysis for tasks 1-8.
# Put shopease_orders.csv in the same folder as this file and run it.

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, confusion_matrix, precision_score, recall_score

FILE = "dataset/shopease_orders.csv"
pd.set_option("display.max_columns", None)
pd.set_option("display.width", 180)
np.random.seed(42)

raw = pd.read_csv(FILE)
print("DATA SHAPE:", raw.shape)
print("COLUMNS:", raw.columns.tolist())

# ------------------------- TASK 1: AUDIT THE DATA -------------------------
print("\nTASK 1")
print("Data types:\n", raw.dtypes)
print("Missing values:\n", raw.isna().sum())
print("Unique values in text columns:\n", raw.select_dtypes(include="object").nunique())

# delivery_days is an object column because the cancelled orders have 'Not shipped'.
print("delivery_days value counts:\n", raw.delivery_days.value_counts())
print("Rows with Not shipped:", raw.delivery_days.eq("Not shipped").sum())

# Repeated order_ids and exact duplicates
repeated_ids = raw.loc[raw.order_id.duplicated(keep=False), "order_id"].unique()
print("Repeated order IDs (distinct IDs):", len(repeated_ids))
print("Rows carrying repeated IDs:", raw.order_id.duplicated(keep=False).sum())
print("Exact duplicate rows:", raw.duplicated().sum())
print("Repeated IDs are exact duplicate copies? Check duplicate rows above; yes these repeated pairs are identical.")

# The strict/default parser flags mixed-format dates. Mixed parser handles both formats.
strict_dates = pd.to_datetime(raw["order_date"], errors="coerce")
mixed_dates = pd.to_datetime(raw["order_date"], format="mixed", errors="coerce")
print("Date strings not in YYYY-MM-DD / NaT with default parser:", strict_dates.isna().sum())
print("Dates successfully parsed using format='mixed':", mixed_dates.notna().sum())
print("Dates still invalid using mixed parser:", mixed_dates.isna().sum())

print("Discount values:", sorted(raw.discount_pct.unique()))
print("Rows with nonzero discount:", raw.discount_pct.ne(0).sum())
print("Rows using percentage scale (values > 1):", raw.discount_pct.gt(1).sum())
print("Raw mean discount value:", raw.discount_pct.mean())
fixed_discount = raw.discount_pct.where(raw.discount_pct <= 1, raw.discount_pct / 100)
print("Mean after fixing scale (fraction):", fixed_discount.mean())
print("Currency counts:\n", raw.currency.value_counts())
print("Unit price by currency:\n", raw.groupby("currency").unit_price.describe())
print("USD unit-price total (USD, not PKR):", raw.loc[raw.currency.eq("USD"), "unit_price"].sum())
print("GUEST rows:", raw.customer_id.eq("GUEST").sum())

# ------------------------- CLEANING USED IN TASKS 2-8 -------------------------
# Remove exact duplicated rows only. Convert date formats safely, correct discount
# scale (fraction <= 1, percentage > 1), and convert USD to PKR at 280.
df = raw.drop_duplicates().copy()
df["date"] = pd.to_datetime(df.order_date, format="mixed", errors="coerce")
df["discount_clean"] = df.discount_pct.where(df.discount_pct <= 1, df.discount_pct / 100)
df["unit_price_pkr"] = df.unit_price.where(df.currency.eq("PKR"), df.unit_price * 280)
df["gross_pkr"] = df.quantity * df.unit_price_pkr
df["revenue_pkr"] = df.gross_pkr * (1 - df.discount_clean)
df["revenue_prompt_discount"] = df.quantity * df.unit_price_pkr * (1 - df.discount_pct / 100)
delivered = df[df.order_status.eq("Delivered")].copy()
returned = delivered.returned.eq("Yes")
net = delivered[~returned].copy()

# ------------------------- TASK 2: REVENUE -------------------------
print("\nTASK 2")
# Prompt version: exact duplicates removed, PKR conversion done, but raw discount scale.
revenue_with_raw_discount = delivered.revenue_prompt_discount.sum()
revenue_corrected = delivered.revenue_pkr.sum()
print("Revenue using raw discount scale (prompt):", revenue_with_raw_discount)
print("Revenue using corrected discount scale:", revenue_corrected)
print("Change after discount correction:", revenue_corrected - revenue_with_raw_discount)

# Leave every listed error in: duplicate rows, no currency conversion, raw discounts.
raw_wrong = raw.copy()
raw_wrong["wrong_revenue"] = raw_wrong.quantity * raw_wrong.unit_price * (1 - raw_wrong.discount_pct / 100)
print("Delivered revenue with all errors retained:", raw_wrong.loc[raw_wrong.order_status.eq("Delivered"), "wrong_revenue"].sum())
print("Revenue by category (corrected, Delivered):\n", delivered.groupby("category").revenue_pkr.sum().sort_values(ascending=False))

returned_revenue = delivered.loc[returned, "revenue_pkr"].sum()
print("Returned orders count:", returned.sum())
print("Value of returned orders (estimated revenue):", returned_revenue)
cat_total = delivered.groupby("category").revenue_pkr.sum()
cat_returned = delivered.loc[returned].groupby("category").revenue_pkr.sum()
cat_return_summary = pd.DataFrame({"total_revenue": cat_total, "returned_value": cat_returned})
cat_return_summary["returned_share"] = cat_return_summary.returned_value / cat_return_summary.total_revenue
print("Category return loss share:\n", cat_return_summary.sort_values("returned_share", ascending=False))
large_order = delivered.loc[delivered.revenue_pkr.idxmax()]
print("Largest order:\n", large_order[["order_id", "customer_id", "category", "quantity", "unit_price", "currency", "discount_pct", "revenue_pkr"]])
print("Net revenue by category (returned excluded):\n", net.groupby("category").revenue_pkr.sum().sort_values(ascending=False))
net_without_big = net.drop(index=large_order.name, errors="ignore")
print("Net category ranking without largest order:\n", net_without_big.groupby("category").revenue_pkr.sum().sort_values(ascending=False))
category_shares = pd.DataFrame({
    "order_share": delivered.category.value_counts(normalize=True),
    "revenue_share": delivered.groupby("category").revenue_pkr.sum() / delivered.revenue_pkr.sum()
})
print("Category order share vs revenue share:\n", category_shares)
category_revenue = delivered.groupby("category").revenue_pkr.sum().sort_values()
plt.figure(figsize=(9, 5))
category_revenue.plot(kind="barh")
plt.title("Delivered Revenue by Category (PKR)")
plt.xlabel("Revenue (PKR)")
plt.ylabel("Category")
plt.tight_layout()
plt.show()

# ------------------------- TASK 3: CHANNEL RETURNS / SIMPSON'S PARADOX -------------------------
print("\nTASK 3")
channel_return = delivered.groupby("channel").returned.agg(n="size", returned_n=lambda s: s.eq("Yes").sum(), return_rate=lambda s: s.eq("Yes").mean())
print("Return rate by channel:\n", channel_return)
channel_category_rates = delivered.pivot_table(index="category", columns="channel", values="returned", aggfunc=lambda x: (x == "Yes").mean())
channel_category_counts = pd.crosstab(delivered.category, delivered.channel)
print("Return rate by category and channel:\n", channel_category_rates)
print("Counts by category/channel:\n", channel_category_counts)
channel_mix = pd.crosstab(delivered.channel, delivered.category, normalize="index")
print("Category mix within each channel:\n", channel_mix)
common_mix = delivered.category.value_counts(normalize=True)
standardized_rates = channel_category_rates.mul(common_mix, axis=0).sum(axis=0)
print("Return rates standardized to common category mix:\n", standardized_rates)
plt.figure(figsize=(7, 4))
channel_return.return_rate.plot(kind="bar")
plt.title("Delivered Return Rate by Channel")
plt.ylabel("Return rate")
plt.xlabel("Channel")
plt.ylim(0, 0.15)
plt.tight_layout()
plt.show()

# ------------------------- TASK 4: FREE DELIVERY / DIFFERENCE-IN-DIFFERENCES -------------------------
print("\nTASK 4")
post = delivered[delivered.date.ge("2025-09-01")].copy()
pre = delivered[delivered.date.lt("2025-09-01")].copy()
print("Free delivery x loyalty (Sep-Dec Delivered):\n", pd.crosstab(post.free_delivery, post.loyalty_member))
print("Sep-Dec group sizes and mean order value:\n", post.groupby("free_delivery").revenue_pkr.agg(["count", "mean", "std"]))
yes = post.loc[post.free_delivery.eq("Yes"), "revenue_pkr"].to_numpy()
no = post.loc[post.free_delivery.eq("No"), "revenue_pkr"].to_numpy()
diff_free = yes.mean() - no.mean()
rng = np.random.default_rng(42)
boot_free = np.array([rng.choice(yes, size=len(yes), replace=True).mean() - rng.choice(no, size=len(no), replace=True).mean() for _ in range(5000)])
print("Free-delivery Yes minus No mean:", diff_free)
print("Bootstrap 95% CI:", np.percentile(boot_free, [2.5, 97.5]))
print("Jan-Aug loyalty groups:\n", pre.groupby("loyalty_member").revenue_pkr.agg(["count", "mean"]))
print("Sep-Dec loyalty groups:\n", post.groupby("loyalty_member").revenue_pkr.agg(["count", "mean"]))
loyal_pre = pre.loc[pre.loyalty_member.eq("Yes"), "revenue_pkr"].to_numpy()
loyal_post = post.loc[post.loyalty_member.eq("Yes"), "revenue_pkr"].to_numpy()
non_pre = pre.loc[pre.loyalty_member.eq("No"), "revenue_pkr"].to_numpy()
non_post = post.loc[post.loyalty_member.eq("No"), "revenue_pkr"].to_numpy()
did = (loyal_post.mean() - loyal_pre.mean()) - (non_post.mean() - non_pre.mean())
boot_did = []
for _ in range(5000):
    lpre = rng.choice(loyal_pre, len(loyal_pre), replace=True).mean()
    lpost = rng.choice(loyal_post, len(loyal_post), replace=True).mean()
    npre = rng.choice(non_pre, len(non_pre), replace=True).mean()
    npost = rng.choice(non_post, len(non_post), replace=True).mean()
    boot_did.append((lpost - lpre) - (npost - npre))
did_ci = np.percentile(boot_did, [2.5, 97.5])
print("Loyalty mean change:", loyal_post.mean() - loyal_pre.mean())
print("Non-loyalty mean change:", non_post.mean() - non_pre.mean())
print("DiD estimate:", did, "CI:", did_ci)
print("DiD as % of loyalty Jan-Aug mean:", 100 * did / loyal_pre.mean())

# ------------------------- TASK 5: RETURN PREDICTION / LEAKAGE -------------------------
print("\nTASK 5")
y = delivered.returned
print("Baseline accuracy (predict No every time): ", y.eq("No").mean())
print("Refund amount > 0 vs returned:\n", pd.crosstab(delivered.refund_amount.gt(0), y))
# First model: leakage included; next: refund_amount removed.
model_data = delivered.copy()
model_data["delivery_days_num"] = pd.to_numeric(model_data.delivery_days, errors="coerce")
feature_columns = [c for c in raw.columns if c != "returned"]
feature_columns = [c for c in feature_columns if c != "delivery_days"] + ["delivery_days_num"]
for remove_refund in [False, True]:
    X = model_data[feature_columns].drop(columns=["refund_amount"]) if remove_refund else model_data[feature_columns]
    y_model = model_data.returned
    train_idx, test_idx = train_test_split(np.arange(len(model_data)), test_size=0.25, random_state=42, stratify=y_model)
    categorical = X.select_dtypes(include="object").columns.tolist()
    numeric = X.select_dtypes(exclude="object").columns.tolist()
    prep = ColumnTransformer([
        ("numeric", Pipeline([("imputer", SimpleImputer(strategy="median"))]), numeric),
        ("categorical", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")), ("onehot", OneHotEncoder(handle_unknown="ignore"))]), categorical)
    ])
    tree = Pipeline([("prep", prep), ("model", DecisionTreeClassifier(random_state=42, max_depth=6))])
    tree.fit(X.iloc[train_idx], y_model.iloc[train_idx])
    prediction = tree.predict(X.iloc[test_idx])
    print("\nRefund column removed?", remove_refund)
    print("Accuracy:", accuracy_score(y_model.iloc[test_idx], prediction))
    print("Confusion matrix (rows actual [No,Yes], columns predicted [No,Yes]):\n", confusion_matrix(y_model.iloc[test_idx], prediction, labels=["No", "Yes"]))
    print("Precision for Yes:", precision_score(y_model.iloc[test_idx], prediction, pos_label="Yes", zero_division=0))
    print("Recall for Yes:", recall_score(y_model.iloc[test_idx], prediction, pos_label="Yes", zero_division=0))
    if not remove_refund:
        names = tree.named_steps["prep"].get_feature_names_out()
        importance = tree.named_steps["model"].feature_importances_
        print("Top features:\n", sorted(zip(names, importance), key=lambda z: z[1], reverse=True)[:10])
print("Return rate by category/channel:\n", delivered.groupby(["category", "channel"]).returned.apply(lambda s: s.eq("Yes").mean()).sort_values(ascending=False))

# ------------------------- TASK 6: CUSTOMER PARETO -------------------------
print("\nTASK 6")
customers = net.groupby("customer_id").agg(revenue=("revenue_pkr", "sum"), orders=("order_id", "count")).sort_values("revenue", ascending=False)
print("Top customer IDs:\n", customers.head(10))
print("GUEST details:\n", customers.loc["GUEST"])
print("B2B-001 details:\n", customers.loc["B2B-001"])
for exclude in [[], ["GUEST"], ["GUEST", "B2B-001"]]:
    ranking = customers.drop(index=exclude, errors="ignore").sort_values("revenue", ascending=False)
    total = ranking.revenue.sum()
    print("Exclusions", exclude)
    for percent in [0.10, 0.20]:
        count = int(np.ceil(len(ranking) * percent))
        print(f"Top {percent:.0%} ({count} IDs) share of revenue:", ranking.head(count).revenue.sum() / total)
named = customers.drop(index=["GUEST", "B2B-001"], errors="ignore")
print("Named customer IDs: one order:", named.orders.eq(1).sum(), "repeat (2+): ", named.orders.ge(2).sum())
print("Repeat named customer revenue share:", named.loc[named.orders.ge(2), "revenue"].sum() / named.revenue.sum())
print("Top 4 named customers:\n", named.head(4))
# Pareto plot top 20 named customer IDs, to avoid anonymous/B2B IDs dominating
pareto = named.head(20).copy()
pareto["cum_share"] = pareto.revenue.cumsum() / named.revenue.sum()
fig, ax = plt.subplots(figsize=(10, 5))
ax.bar(pareto.index, pareto.revenue)
ax.set_ylabel("Net revenue (PKR)")
ax.set_xlabel("Customer ID")
ax.set_title("Top 20 Named Customers: Net Revenue and Cumulative Share")
ax.tick_params(axis="x", rotation=75)
ax2 = ax.twinx()
ax2.plot(pareto.index, pareto.cum_share, marker="o")
ax2.set_ylabel("Cumulative share of named-customer revenue")
ax2.set_ylim(0, 1)
plt.tight_layout()
plt.show()

# ------------------------- TASK 7: RETURN TREND / RIGHT-CENSORING -------------------------
print("\nTASK 7")
monthly_return = delivered.groupby(delivered.date.dt.month).returned.agg(returned_n=lambda s: s.eq("Yes").sum(), n="size", rate=lambda s: s.eq("Yes").mean())
monthly_return.index = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
print("Monthly return rates:\n", monthly_return)
december = delivered[delivered.date.dt.month.eq(12)].copy()
december["week_bucket"] = pd.cut(december.date.dt.day, bins=[0, 7, 14, 21, 31], labels=["1-7", "8-14", "15-21", "22-31"])
print("December weekly buckets:\n", december.groupby("week_bucket", observed=False).returned.agg(returned_n=lambda s: s.eq("Yes").sum(), n="size", rate=lambda s: s.eq("Yes").mean()))
# Dates are now safely parsed; order cutoff does not eliminate late-November/December
# observation lag. November comparison for Black Friday dates 24-30.
through_nov = delivered[delivered.date.le("2025-11-30")]
print("Monthly rates for data through Nov 30:\n", through_nov.groupby(through_nov.date.dt.month).returned.agg(returned_n=lambda s: s.eq("Yes").sum(), n="size", rate=lambda s: s.eq("Yes").mean()))
november = delivered[delivered.date.dt.month.eq(11)]
black_friday = november[november.date.dt.day.between(24, 30)]
rest_nov = november[~november.date.dt.day.between(24, 30)]
print("Black Friday week return rate and n:", len(black_friday), black_friday.returned.eq("Yes").mean())
print("Rest of November return rate and n:", len(rest_nov), rest_nov.returned.eq("Yes").mean())
plt.figure(figsize=(9, 4))
plt.plot(monthly_return.index, monthly_return.rate, marker="o")
plt.title("Monthly Return Rate for Delivered Orders")
plt.xlabel("Order month")
plt.ylabel("Return rate")
plt.xticks(rotation=30)
plt.tight_layout()
plt.show()

# ------------------------- TASK 8: REVENUE & ORDERS -------------------------
print("\nTASK 8")
monthly = delivered.groupby(delivered.date.dt.month).agg(
    orders=("order_id", "count"), revenue=("revenue_pkr", "sum"),
    revenue_before_discount=("gross_pkr", "sum"), simple_discount=("discount_clean", "mean")
)
monthly["aov"] = monthly.revenue / monthly.orders
monthly["order_index"] = monthly.orders / monthly.orders.iloc[0] * 100
monthly["revenue_index"] = monthly.revenue / monthly.revenue.iloc[0] * 100
monthly["weighted_discount"] = 1 - monthly.revenue / monthly.revenue_before_discount
print("Monthly orders/revenue/AOV/index/discount table:\n", monthly)
print("October vs November:\n", monthly.loc[[10, 11], ["orders", "revenue", "aov"]])
print("November indexes (Jan=100):\n", monthly.loc[11, ["order_index", "revenue_index"]])

# Dual axis illustration - axes can be independently rescaled, visually changing gaps.
fig, ax1 = plt.subplots(figsize=(10, 5))
ax1.plot(monthly.index, monthly.revenue / 1_000_000, marker="o", label="Revenue (million PKR)")
ax1.set_ylabel("Revenue (million PKR)")
ax1.set_xlabel("Month number")
ax2 = ax1.twinx()
ax2.plot(monthly.index, monthly.orders, marker="s", label="Order count")
ax2.set_ylabel("Orders")
plt.title("Monthly Revenue and Orders (Dual Axes)")
plt.tight_layout()
plt.show()

# Better comparison: index both series to January = 100 on a single axis.
plt.figure(figsize=(9, 5))
plt.plot(monthly.index, monthly.order_index, marker="o", label="Orders index")
plt.plot(monthly.index, monthly.revenue_index, marker="s", label="Revenue index")
plt.title("Orders and Revenue Index (January = 100)")
plt.xlabel("Month number")
plt.ylabel("Index")
plt.legend()
plt.tight_layout()
plt.show()

# Black Friday simple mean discount: compare cleaned orders from 24-30 Nov vs rest of Nov.
nov_all = df[df.date.dt.month.eq(11)]
nov_bf = nov_all[nov_all.date.dt.day.between(24, 30)]
nov_rest = nov_all[~nov_all.date.dt.day.between(24, 30)]
print("Value-weighted discount by month:\n", monthly.weighted_discount)
print("Simple average discount Black Friday dates:", nov_bf.discount_clean.mean(), "n:", len(nov_bf))
print("Simple average discount rest of November:", nov_rest.discount_clean.mean(), "n:", len(nov_rest))
# June unusually high due to B2B-001 large Home order; remove it and re-index.
june = delivered[delivered.date.dt.month.eq(6)].copy()
june_big = june.loc[june.revenue_pkr.idxmax()]
june_without = june.drop(index=june_big.name)
print("Largest June order:\n", june_big[["order_id", "customer_id", "category", "quantity", "unit_price", "discount_clean", "revenue_pkr"]])
print("June total revenue:", june.revenue_pkr.sum())
print("June revenue index:", monthly.loc[6, "revenue_index"])
print("June index after removing largest order:", june_without.revenue_pkr.sum() / monthly.loc[1, "revenue"] * 100)
print("Monthly order-revenue correlation:", monthly.orders.corr(monthly.revenue))
print("\nEND OF LAB 12")
